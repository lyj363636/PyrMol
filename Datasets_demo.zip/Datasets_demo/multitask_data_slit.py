import os
import numpy as np
import pandas as pd
import json
import torch
from sklearn.model_selection import train_test_split
from rdkit import Chem
import random
from collections import defaultdict
from rdkit.Chem.Scaffolds import MurckoScaffold
from random import Random

def fix_train_random_seed(seed=2021):
    # fix random seeds
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.enabled = False


class MolGraphSet():
    def __init__(self, df, target):
        self.data = df
        self.target = target
        self.mols = []
        self.labels = []
        self.smiles = []
        self.generate_data()

    def generate_data(self):
        for i, row in self.data.iterrows():
            smi = row['smiles']
            label = row[self.target].values.astype(float)
            try:
                mol = Chem.MolFromSmiles(smi)
                if mol is None:
                    print('invalid', smi)
                else:
                    self.mols.append(mol)
                    self.smiles.append(smi)
                    self.labels.append(label)
            except Exception as e:
                print(e, 'invalid', smi)



def scaffold_split(mol_list, frac=None, balanced=False, include_chirality=False, ramdom_state=0):
    if frac is None:
        frac = [0.8, 0.1, 0.1]
    assert sum(frac) == 1

    n_total_valid = int(np.floor(frac[1] * len(mol_list)))
    n_total_test = int(np.floor(frac[2] * len(mol_list)))
    n_total_train = len(mol_list) - n_total_valid - n_total_test

    scaffolds_sets = defaultdict(list)
    for idx, mol in enumerate(mol_list):
        scaffold = MurckoScaffold.MurckoScaffoldSmiles(mol=mol, includeChirality=include_chirality)
        scaffolds_sets[scaffold].append(idx)

    random = Random(ramdom_state)

    # Put stuff that's bigger than half the val/test size into train, rest just order randomly
    if balanced:
        index_sets = list(scaffolds_sets.values())
        big_index_sets, small_index_sets = list(), list()
        for index_set in index_sets:
            if len(index_set) > n_total_valid / 2 or len(index_set) > n_total_test / 2:
                big_index_sets.append(index_set)
            else:
                small_index_sets.append(index_set)

        random.seed(ramdom_state)
        random.shuffle(big_index_sets)
        random.shuffle(small_index_sets)
        index_sets = big_index_sets + small_index_sets
    else:  # Sort from largest to smallest scaffold sets
        index_sets = sorted(list(scaffolds_sets.values()), key=lambda index_set: len(index_set), reverse=True)

    train_index, valid_index, test_index = list(), list(), list()
    for index_set in index_sets:
        if len(train_index) + len(index_set) <= n_total_train:
            train_index += index_set
        elif len(valid_index) + len(index_set) <= n_total_valid:
            valid_index += index_set
        else:
            test_index += index_set

    return train_index, valid_index, test_index

if __name__ == '__main__':
    for dataset_name in ["clintox","muv","sider","tox21","toxcast"]:
    # for dataset_name in ["clintox"]:
        print(dataset_name)
        seeds = [0,100,200,300,400]
        folds = 5
        split_mode = 'scaffold'
        save_path = f"./{dataset_name}"
        os.makedirs(save_path, exist_ok=True)
        data_df = pd.read_csv(f"./{dataset_name}.csv")
        label_names = data_df.columns[1:]
        dataset = MolGraphSet(data_df, label_names)
        for seed in seeds:
            fix_train_random_seed(seed)
            for fold in range(folds):
                if split_mode == 'scaffold':
                    train_index, valid_index, test_index = scaffold_split(dataset.mols, frac=[0.8, 0.1, 0.1], balanced=True,
                                                                          include_chirality=False, ramdom_state=seed + fold)

                    train_dataset, val_dataset, test_dataset = data_df.iloc[train_index],data_df.iloc[valid_index],data_df.iloc[test_index]

                elif split_mode == 'random':
                    train_valid_dataset, test_dataset = train_test_split(data_df, test_size=0.1, random_state=seed + fold)
                    train_dataset, val_dataset = train_test_split(train_valid_dataset, test_size=len(test_dataset),
                                                                  random_state=seed + fold)
                print(f'dataset size, train: {len(train_dataset)}, \
                                    val: {len(val_dataset)}, \
                                    test: {len(test_dataset)}')

                train_dataset.to_csv(f"{save_path}/{seed}_fold_{fold}_train.csv", index=False)
                val_dataset.to_csv(f"{save_path}/{seed}_fold_{fold}_valid.csv", index=False)
                test_dataset.to_csv(f"{save_path}/{seed}_fold_{fold}_test.csv", index=False)

